Brute L4 DDOS Tool Python

Brute is the best L4 DoS tool in Python3.

It will flood the victim's router with UDP packets, so even if there are no ports opened,
the router will still be overwhelmed and slowed down.
Brute allows you to DoS Fivem, Minecraft, or even normal servers.
But it can also down a simple family network.

Features 
+ The only limit... is you! The faster your connection is, the more powerful will be the attack
+ Show informations about the attack in real time
+ Can down servers but also family networks

Note: The Author of this tool is not responsible for your actions.

Usage:

[+] Enter the IP to Brutalize 
[+] Enter port
[+] Bytes per packet [press enter for 1250] ->
[+] Set The Threads [press enter for 100]